using TerrariaRelay.Protocol;
using TerrariaRelay.Server;
using System.Net;
using System.Net.Sockets;
using System.Text;

await SuccessfulRoundTrip();
await BadMagicIsRejected();
IniConfigurationIsLoadedAndCliOverrides();
await EndToEndIpv6Relay();
Console.WriteLine("All protocol and IPv6 relay tests passed.");

static async Task SuccessfulRoundTrip()
{
    using var stream = new MemoryStream();
    await RelayProtocol.WriteResponseAsync(stream, true, "OK", CancellationToken.None);
    stream.Position = 0;
    var response = await RelayProtocol.ReadResponseAsync(stream, CancellationToken.None);
    Assert(response == (true, "OK"), "response round-trip");
}

static async Task BadMagicIsRejected()
{
    using var stream = new MemoryStream(new byte[8]);
    try
    {
        await RelayProtocol.AuthenticateAsServerAsync(stream, "expected-token", CancellationToken.None);
        throw new Exception("bad magic was accepted");
    }
    catch (RelayProtocolException) { }
}

static void IniConfigurationIsLoadedAndCliOverrides()
{
    string path = Path.Combine(Path.GetTempPath(), $"terraria-relay-{Guid.NewGuid():N}.ini");
    try
    {
        File.WriteAllText(path, """
[server]
listen_address = ::1
listen_port = 18000
target_host = ::1
target_port = 7777
token = integration-test-token
max_connections = 12
connect_timeout = 7
handshake_timeout = 8
keepalive = 20
""");
        ServerOptions options = ServerOptions.Parse(["--config", path, "--listen-port", "18001"]);
        Assert(options.ListenPort == 18001, "CLI overrides INI");
        Assert(options.MaxConnections == 12, "INI max connections");
        Assert(options.TargetHost == "::1" && options.Token == "integration-test-token", "INI target and token");
    }
    finally
    {
        File.Delete(path);
    }
}

static async Task EndToEndIpv6Relay()
{
    const string token = "integration-test-token";
    var echo = new TcpListener(IPAddress.IPv6Loopback, 0);
    echo.Server.DualMode = false;
    echo.Start();
    int echoPort = ((IPEndPoint)echo.LocalEndpoint).Port;
    int relayPort = ReserveIpv6Port();
    using var cancellation = new CancellationTokenSource(TimeSpan.FromSeconds(10));

    Task echoTask = Task.Run(async () =>
    {
        using Socket socket = await echo.AcceptSocketAsync(cancellation.Token);
        using var stream = new NetworkStream(socket);
        byte[] buffer = new byte[4096];
        while (true)
        {
            int read = await stream.ReadAsync(buffer, cancellation.Token);
            if (read == 0) break;
            await stream.WriteAsync(buffer.AsMemory(0, read), cancellation.Token);
        }
    });

    var options = new ServerOptions(IPAddress.IPv6Loopback, relayPort, "::1", echoPort, token, 8, 3, 3, 5);
    Task serverTask = new RelayServer(options).RunAsync(cancellation.Token);
    try
    {
        using Socket client = await SocketUtilities.ConnectAsync("::1", relayPort, TimeSpan.FromSeconds(3), 5, true, cancellation.Token);
        using var stream = new NetworkStream(client, ownsSocket: false);
        await RelayProtocol.AuthenticateAsClientAsync(stream, token, cancellation.Token);
        var response = await RelayProtocol.ReadResponseAsync(stream, cancellation.Token);
        Assert(response.Success, "relay authentication");

        byte[] payload = Encoding.UTF8.GetBytes("Terraria IPv6 relay integration payload");
        await stream.WriteAsync(payload, cancellation.Token);
        byte[] echoed = new byte[payload.Length];
        await ReadExactly(stream, echoed, cancellation.Token);
        Assert(payload.SequenceEqual(echoed), "end-to-end relay payload");
        client.Shutdown(SocketShutdown.Both);
    }
    finally
    {
        cancellation.Cancel();
        echo.Stop();
        try { await Task.WhenAll(serverTask, echoTask); } catch (OperationCanceledException) { }
    }
}

static int ReserveIpv6Port()
{
    var listener = new TcpListener(IPAddress.IPv6Loopback, 0);
    listener.Start();
    int port = ((IPEndPoint)listener.LocalEndpoint).Port;
    listener.Stop();
    return port;
}

static async Task ReadExactly(Stream stream, Memory<byte> buffer, CancellationToken cancellationToken)
{
    int offset = 0;
    while (offset < buffer.Length)
    {
        int read = await stream.ReadAsync(buffer[offset..], cancellationToken);
        if (read == 0) throw new EndOfStreamException();
        offset += read;
    }
}

static void Assert(bool condition, string name)
{
    if (!condition) throw new Exception($"Assertion failed: {name}");
}
