# Terraria IPv6 Relay

一个面向 Terraria TCP 联机的轻量 IPv6 中继。Ubuntu 服务端固定连接到指定的 Terraria 服务器，Windows 客户端在本机提供 `127.0.0.1:7777` 入口。

```text
Terraria 客户端 -> 127.0.0.1:7777 -> Windows Relay Client
               -> IPv6 Internet -> Ubuntu Relay Server -> Terraria Server:7777
```

## 快速开始

### 1. Ubuntu 启动中继服务端

将 Ubuntu 压缩包上传并解压，编辑 `terraria-relay.ini`：

```ini
[server]
listen_address = ::
listen_port = 17777
target_host = ::1
target_port = 7777
token = 请换成至少16位随机字符串
max_connections = 64
connect_timeout = 10
handshake_timeout = 10
keepalive = 15
```

然后运行：

```bash
chmod +x TerrariaRelay.Server
chmod 600 terraria-relay.ini
./TerrariaRelay.Server --config ./terraria-relay.ini
```

- `--listen-address` 默认 `::`，只监听 IPv6。
- `--target-host` 是真正的 Terraria 服务器地址。若 Terraria 服务端与中继在同一台 Ubuntu 上，使用 `::1`。
- 防火墙只需放行中继端口，例如 `sudo ufw allow 17777/tcp`；不必向公网暴露 Terraria 的 `7777`。
- 用 `./TerrariaRelay.Server --help` 查看全部参数。
- 命令行参数会覆盖 INI，例如临时换端口：`./TerrariaRelay.Server --config ./terraria-relay.ini --listen-port 18888`。

可选：作为 systemd 服务运行（压缩包内已附模板）：

```bash
sudo useradd --system --no-create-home --shell /usr/sbin/nologin terraria-relay
sudo mkdir -p /opt/terraria-relay
sudo cp TerrariaRelay.Server /opt/terraria-relay/
sudo chmod 755 /opt/terraria-relay/TerrariaRelay.Server
sudo cp terraria-relay.service /etc/systemd/system/
sudo cp terraria-relay.ini /etc/terraria-relay.ini
sudo chown root:terraria-relay /etc/terraria-relay.ini
sudo chmod 640 /etc/terraria-relay.ini
# 编辑 /etc/terraria-relay.ini 中的令牌和端口
sudo systemctl daemon-reload
sudo systemctl enable --now terraria-relay
```

### 2. Windows 客户端

先完整解压 Windows 压缩包，再运行 `TerrariaRelay.Client.exe`。填写 Ubuntu 的公网 IPv6 或域名（IPv6 无需手动加 `[]`）、端口和同一个令牌，点击“启动中继”。客户端会先执行真实握手；成功后顶部显示“握手成功”，日志显示 Terraria 服务端可达。不要直接在压缩软件的预览窗口内运行 EXE。窗口标题应显示 `v1.2.1`。

“流量统计”页按 1 秒采样，显示最近 10 分钟的上传/下载速度曲线，以及当前速度、活跃连接、累计流量和本次运行时长。

然后在 Terraria 中选择“通过 IP 加入”，地址填写 `127.0.0.1`，端口填写 `7777`。

配置保存在 `%LOCALAPPDATA%\TerrariaIPv6Relay\config.json`，令牌使用 Windows DPAPI 加密后保存。

## 从源码构建

需要 .NET 10 SDK。

Windows PowerShell：

```powershell
.\scripts\build.ps1
```

构建结果：

- `outputs/windows/TerrariaRelay.Client.exe`
- `outputs/ubuntu-x64/TerrariaRelay.Server`
- `outputs/TerrariaRelay-Source.zip`

也可以在 Ubuntu 上只构建服务端：

```bash
./scripts/build-server.sh
```

## 稳定性与安全设计

- 每个 Terraria 连接建立独立的中继 TCP 连接，某个玩家断线不会影响其他连接。
- 两端启用 TCP keepalive 和 `TCP_NODELAY`，连接和握手都有超时。
- 令牌使用随机挑战 + HMAC-SHA256 验证，不直接在公网传输，并使用固定时间比较；错误日志不会输出令牌。
- 服务端目标地址由管理员启动时固定，客户端不能把它当作任意 TCP 代理。
- 默认并发上限为 64，避免异常连接耗尽服务器资源。
- 支持 Ctrl+C / SIGTERM 优雅退出。

> 本项目的中继协议不加密 Terraria 游戏流量。鉴权令牌不会直接上网传输；若游戏内容也需要保密，建议在两端额外使用 WireGuard。
