param([string]$Configuration = "Release")
$ErrorActionPreference = "Stop"
$root = Split-Path -Parent $PSScriptRoot
$dotnet = Join-Path $root "work\.dotnet\dotnet.exe"
if (-not (Test-Path $dotnet)) { $dotnet = "dotnet" }
$winOut = Join-Path $root "outputs\windows"
$linuxOut = Join-Path $root "outputs\ubuntu-x64"

& $dotnet build (Join-Path $root "TerrariaRelay.slnx") -c $Configuration
& $dotnet run --project (Join-Path $root "tests\TerrariaRelay.Tests\TerrariaRelay.Tests.csproj") -c $Configuration --no-build
& $dotnet publish (Join-Path $root "src\TerrariaRelay.Client\TerrariaRelay.Client.csproj") -c $Configuration -r win-x64 --self-contained true -p:PublishSingleFile=true -p:IncludeNativeLibrariesForSelfExtract=true -o $winOut
& $dotnet publish (Join-Path $root "src\TerrariaRelay.Server\TerrariaRelay.Server.csproj") -c $Configuration -r linux-x64 --self-contained true -p:PublishSingleFile=true -p:PublishTrimmed=true -o $linuxOut

$windowsVersionedZip = Join-Path $root "outputs\TerrariaRelay-Windows-x64-v1.2.0.zip"
Compress-Archive -Path @(
    (Join-Path $winOut "TerrariaRelay.Client.exe"),
    (Join-Path $root "README.md")
) -DestinationPath $windowsVersionedZip -Force
try {
    Copy-Item $windowsVersionedZip (Join-Path $root "outputs\TerrariaRelay-Windows-x64.zip") -Force
}
catch {
    Write-Warning "通用 Windows ZIP 正被占用，已保留新的带版本号压缩包。"
}
$ubuntuVersionedZip = Join-Path $root "outputs\TerrariaRelay-Ubuntu-x64-v1.1.1.zip"
Compress-Archive -Path @(
    (Join-Path $linuxOut "TerrariaRelay.Server"),
    (Join-Path $root "README.md"),
    (Join-Path $root "deploy\terraria-relay.service"),
    (Join-Path $root "deploy\terraria-relay.ini")
) -DestinationPath $ubuntuVersionedZip -Force
try {
    Copy-Item $ubuntuVersionedZip (Join-Path $root "outputs\TerrariaRelay-Ubuntu-x64.zip") -Force
}
catch {
    Write-Warning "通用 Ubuntu ZIP 正被占用，已保留新的带版本号压缩包。"
}

$sourceZip = Join-Path $root "outputs\TerrariaRelay-Source.zip"
$sourceStream = [System.IO.File]::Open($sourceZip, [System.IO.FileMode]::Create)
$sourceArchive = [System.IO.Compression.ZipArchive]::new(
    $sourceStream, [System.IO.Compression.ZipArchiveMode]::Create)
try {
    $sourceRoots = @("src", "tests", "scripts", "deploy")
    $sourceFiles = foreach ($sourceRoot in $sourceRoots) {
        Get-ChildItem (Join-Path $root $sourceRoot) -File -Recurse |
            Where-Object { $_.FullName -notmatch '[\\/](bin|obj)[\\/]' }
    }
    $sourceFiles += Get-Item @(
        (Join-Path $root "README.md"),
        (Join-Path $root "Directory.Build.props"),
        (Join-Path $root "TerrariaRelay.slnx")
    )
    foreach ($file in $sourceFiles) {
        $entryName = [System.IO.Path]::GetRelativePath($root, $file.FullName).Replace('\', '/')
        [System.IO.Compression.ZipFileExtensions]::CreateEntryFromFile(
            $sourceArchive, $file.FullName, $entryName,
            [System.IO.Compression.CompressionLevel]::Optimal) | Out-Null
    }
}
finally {
    $sourceArchive.Dispose()
    $sourceStream.Dispose()
}
Copy-Item (Join-Path $root "README.md") (Join-Path $root "outputs\README.md") -Force

Write-Host "Build complete:" -ForegroundColor Green
Write-Host (Join-Path $winOut "TerrariaRelay.Client.exe")
Write-Host (Join-Path $linuxOut "TerrariaRelay.Server")
