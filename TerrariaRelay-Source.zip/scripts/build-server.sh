#!/usr/bin/env bash
set -euo pipefail
ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
dotnet publish "$ROOT/src/TerrariaRelay.Server/TerrariaRelay.Server.csproj" \
  -c Release -r linux-x64 --self-contained true \
  -p:PublishSingleFile=true -p:PublishTrimmed=true \
  -o "$ROOT/outputs/ubuntu-x64"
echo "Built: $ROOT/outputs/ubuntu-x64/TerrariaRelay.Server"
