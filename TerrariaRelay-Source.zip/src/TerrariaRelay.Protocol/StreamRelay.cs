using System.Net.Sockets;

namespace TerrariaRelay.Protocol;

public static class StreamRelay
{
    public static async Task<(long Upstream, long Downstream)> RunAsync(
        Socket left,
        Socket right,
        Action<long, long>? onBytes,
        CancellationToken cancellationToken)
    {
        using var leftStream = new NetworkStream(left, ownsSocket: false);
        using var rightStream = new NetworkStream(right, ownsSocket: false);
        using var relayCts = CancellationTokenSource.CreateLinkedTokenSource(cancellationToken);

        Task<long> upstream = CopyAsync(leftStream, rightStream, left, right, true, onBytes, relayCts.Token);
        Task<long> downstream = CopyAsync(rightStream, leftStream, right, left, false, onBytes, relayCts.Token);
        Task<long> first = await Task.WhenAny(upstream, downstream);
        if (first.IsFaulted || first.IsCanceled)
            relayCts.Cancel();
        await Task.WhenAll(IgnoreExpectedDisconnect(upstream), IgnoreExpectedDisconnect(downstream));
        return (upstream.IsCompletedSuccessfully ? upstream.Result : 0,
                downstream.IsCompletedSuccessfully ? downstream.Result : 0);
    }

    private static async Task<long> CopyAsync(
        Stream source,
        Stream destination,
        Socket sourceSocket,
        Socket destinationSocket,
        bool isUpstream,
        Action<long, long>? onBytes,
        CancellationToken cancellationToken)
    {
        byte[] buffer = new byte[64 * 1024];
        long total = 0;
        while (true)
        {
            try
            {
                int read = await source.ReadAsync(buffer, cancellationToken);
                if (read == 0)
                {
                    TryShutdown(destinationSocket, SocketShutdown.Send);
                    break;
                }

                await destination.WriteAsync(buffer.AsMemory(0, read), cancellationToken);
                total += read;
                onBytes?.Invoke(isUpstream ? read : 0, isUpstream ? 0 : read);
            }
            catch
            {
                TryShutdown(sourceSocket, SocketShutdown.Both);
                TryShutdown(destinationSocket, SocketShutdown.Both);
                throw;
            }
        }
        TryShutdown(sourceSocket, SocketShutdown.Receive);
        return total;
    }

    private static async Task IgnoreExpectedDisconnect(Task task)
    {
        try { await task; }
        catch (IOException) { }
        catch (SocketException) { }
        catch (ObjectDisposedException) { }
        catch (OperationCanceledException) { }
    }

    private static void TryShutdown(Socket socket, SocketShutdown how)
    {
        try { socket.Shutdown(how); }
        catch (SocketException) { }
        catch (ObjectDisposedException) { }
    }
}
