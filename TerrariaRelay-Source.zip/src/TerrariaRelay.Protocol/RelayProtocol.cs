using System.Security.Cryptography;
using System.Text;

namespace TerrariaRelay.Protocol;

public static class RelayProtocol
{
    private static readonly byte[] Magic = "TRLYv002"u8.ToArray();
    private const int ChallengeLength = 32;
    private const int ProofLength = 32;
    public const int MaxTokenBytes = 512;
    public const int MaxMessageBytes = 1024;

    public static async Task AuthenticateAsClientAsync(Stream stream, string token, CancellationToken cancellationToken)
    {
        byte[] tokenBytes = Encoding.UTF8.GetBytes(token);
        if (tokenBytes.Length is 0 or > MaxTokenBytes)
            throw new RelayProtocolException($"令牌长度必须为 1 到 {MaxTokenBytes} 字节。");

        await stream.WriteAsync(Magic, cancellationToken);
        await stream.FlushAsync(cancellationToken);

        byte[] challenge = new byte[ChallengeLength];
        await ReadExactlyAsync(stream, challenge, cancellationToken);
        byte[] proof = HMACSHA256.HashData(tokenBytes, challenge);
        await stream.WriteAsync(proof, cancellationToken);
        await stream.FlushAsync(cancellationToken);
        CryptographicOperations.ZeroMemory(tokenBytes);
    }

    public static async Task<bool> AuthenticateAsServerAsync(Stream stream, string expectedToken, CancellationToken cancellationToken)
    {
        byte[] receivedMagic = new byte[Magic.Length];
        await ReadExactlyAsync(stream, receivedMagic, cancellationToken);
        if (!CryptographicOperations.FixedTimeEquals(receivedMagic, Magic))
            throw new RelayProtocolException("无效的协议标识。");

        byte[] tokenBytes = Encoding.UTF8.GetBytes(expectedToken);
        byte[] challenge = RandomNumberGenerator.GetBytes(ChallengeLength);
        await stream.WriteAsync(challenge, cancellationToken);
        await stream.FlushAsync(cancellationToken);
        byte[] receivedProof = new byte[ProofLength];
        await ReadExactlyAsync(stream, receivedProof, cancellationToken);
        byte[] expectedProof = HMACSHA256.HashData(tokenBytes, challenge);
        bool valid = CryptographicOperations.FixedTimeEquals(receivedProof, expectedProof);
        CryptographicOperations.ZeroMemory(tokenBytes);
        CryptographicOperations.ZeroMemory(expectedProof);
        return valid;
    }

    public static async Task WriteResponseAsync(Stream stream, bool success, string message, CancellationToken cancellationToken)
    {
        byte[] messageBytes = Encoding.UTF8.GetBytes(message);
        if (messageBytes.Length > MaxMessageBytes)
            messageBytes = messageBytes[..MaxMessageBytes];

        byte[] header = new byte[3];
        header[0] = success ? (byte)0 : (byte)1;
        System.Buffers.Binary.BinaryPrimitives.WriteUInt16BigEndian(header.AsSpan(1), (ushort)messageBytes.Length);
        await stream.WriteAsync(header, cancellationToken);
        await stream.WriteAsync(messageBytes, cancellationToken);
        await stream.FlushAsync(cancellationToken);
    }

    public static async Task<(bool Success, string Message)> ReadResponseAsync(Stream stream, CancellationToken cancellationToken)
    {
        byte[] header = new byte[3];
        await ReadExactlyAsync(stream, header, cancellationToken);
        int length = System.Buffers.Binary.BinaryPrimitives.ReadUInt16BigEndian(header.AsSpan(1));
        if (length > MaxMessageBytes)
            throw new RelayProtocolException("服务端响应过长。");

        byte[] message = new byte[length];
        await ReadExactlyAsync(stream, message, cancellationToken);
        return (header[0] == 0, Encoding.UTF8.GetString(message));
    }

    private static async Task ReadExactlyAsync(Stream stream, Memory<byte> buffer, CancellationToken cancellationToken)
    {
        int offset = 0;
        while (offset < buffer.Length)
        {
            int read = await stream.ReadAsync(buffer[offset..], cancellationToken);
            if (read == 0)
                throw new EndOfStreamException("连接在协议数据接收完成前关闭。");
            offset += read;
        }
    }
}

public sealed class RelayProtocolException(string message) : Exception(message);
