using System.Net;
using System.Net.Sockets;

namespace TerrariaRelay.Protocol;

public static class SocketUtilities
{
    public static void Configure(Socket socket, int keepAliveSeconds)
    {
        socket.NoDelay = true;
        socket.SetSocketOption(SocketOptionLevel.Socket, SocketOptionName.KeepAlive, true);
        TrySet(socket, SocketOptionName.TcpKeepAliveTime, keepAliveSeconds);
        TrySet(socket, SocketOptionName.TcpKeepAliveInterval, Math.Max(1, keepAliveSeconds / 3));
        TrySet(socket, SocketOptionName.TcpKeepAliveRetryCount, 5);
    }

    public static async Task<Socket> ConnectAsync(
        string host,
        int port,
        TimeSpan timeout,
        int keepAliveSeconds,
        bool requireIpv6,
        CancellationToken cancellationToken)
    {
        string normalizedHost = NormalizeHost(host);
        IPAddress[] addresses = await Dns.GetHostAddressesAsync(normalizedHost, cancellationToken);
        IPAddress[] candidates = addresses
            .Where(a => !requireIpv6 || a.AddressFamily == AddressFamily.InterNetworkV6)
            .OrderByDescending(a => a.AddressFamily == AddressFamily.InterNetworkV6)
            .ToArray();

        if (candidates.Length == 0)
            throw new SocketException(requireIpv6 ? (int)SocketError.AddressFamilyNotSupported : (int)SocketError.HostNotFound);

        Exception? lastError = null;
        foreach (IPAddress address in candidates)
        {
            var socket = new Socket(address.AddressFamily, SocketType.Stream, ProtocolType.Tcp);
            Configure(socket, keepAliveSeconds);
            try
            {
                using var timeoutCts = CancellationTokenSource.CreateLinkedTokenSource(cancellationToken);
                timeoutCts.CancelAfter(timeout);
                await socket.ConnectAsync(new IPEndPoint(address, port), timeoutCts.Token);
                return socket;
            }
            catch (Exception ex) when (ex is SocketException or OperationCanceledException)
            {
                lastError = ex;
                socket.Dispose();
            }
        }

        throw lastError ?? new SocketException((int)SocketError.NotConnected);
    }

    public static string NormalizeHost(string host)
    {
        string value = host.Trim();
        if (value.StartsWith('[') && value.EndsWith(']'))
            return value[1..^1];
        return value;
    }

    private static void TrySet(Socket socket, SocketOptionName name, int value)
    {
        try { socket.SetSocketOption(SocketOptionLevel.Tcp, name, value); }
        catch (SocketException) { }
        catch (PlatformNotSupportedException) { }
    }
}
