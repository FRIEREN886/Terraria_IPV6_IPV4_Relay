using System.Net;

namespace TerrariaRelay.Server;

internal sealed record ServerOptions(
    IPAddress ListenAddress,
    int ListenPort,
    string TargetHost,
    int TargetPort,
    string Token,
    int MaxConnections,
    int ConnectTimeoutSeconds,
    int HandshakeTimeoutSeconds,
    int KeepAliveSeconds)
{
    public static string Help => """
Terraria IPv6 Relay Server

用法:
  TerrariaRelay.Server --config /etc/terraria-relay.ini
  TerrariaRelay.Server --target-host <地址> --token <令牌> [选项]

必填:
  --target-host <地址>           Terraria 服务端地址，例如 ::1
  --token <令牌>                客户端鉴权令牌（建议至少 16 个字符）

选项:
  --config <路径>               INI 配置文件路径
  --listen-address <IPv6>       监听地址，默认 ::
  --listen-port <1-65535>       中继端口，默认 17777
  --target-port <1-65535>       Terraria 端口，默认 7777
  --max-connections <数量>      最大并发连接，默认 64
  --connect-timeout <秒>        连接目标超时，默认 10
  --handshake-timeout <秒>      客户端握手超时，默认 10
  --keepalive <秒>              TCP keepalive 空闲时间，默认 15
  --help                        显示帮助

命令行参数优先于 INI。未指定 --config 时会自动读取当前目录的 terraria-relay.ini（如果存在）。
也可通过 TERRARIA_RELAY_CONFIG 和 TERRARIA_RELAY_TOKEN 环境变量提供配置路径与令牌。
""";

    public static ServerOptions Parse(string[] args)
    {
        var allowedCliKeys = new HashSet<string>(StringComparer.OrdinalIgnoreCase)
        {
            "--config", "--listen-address", "--listen-port", "--target-host", "--target-port",
            "--token", "--max-connections", "--connect-timeout", "--handshake-timeout", "--keepalive",
            "--help"
        };
        var values = new Dictionary<string, string>(StringComparer.OrdinalIgnoreCase);
        for (int i = 0; i < args.Length; i++)
        {
            if (args[i] is "--help" or "-h")
            {
                values["--help"] = "true";
                continue;
            }
            if (!args[i].StartsWith("--", StringComparison.Ordinal) || !allowedCliKeys.Contains(args[i]))
                throw new ArgumentException($"未知参数: {args[i]}");
            if (++i >= args.Length)
                throw new ArgumentException($"参数 {args[i - 1]} 缺少值。");
            values[args[i - 1]] = args[i];
        }

        string? explicitConfig = values.GetValueOrDefault("--config") ??
                                 Environment.GetEnvironmentVariable("TERRARIA_RELAY_CONFIG");
        string defaultConfig = Path.Combine(Environment.CurrentDirectory, "terraria-relay.ini");
        string? configPath = explicitConfig ?? (File.Exists(defaultConfig) ? defaultConfig : null);
        IniConfiguration? ini = configPath is null ? null : IniConfiguration.Load(configPath);
        var allowedIniKeys = new HashSet<string>(StringComparer.OrdinalIgnoreCase)
        {
            "listen_address", "listen_port", "target_host", "target_port", "token",
            "max_connections", "connect_timeout", "handshake_timeout", "keepalive"
        };
        ini?.ValidateServerKeys(allowedIniKeys);

        string Get(string cliKey, string iniKey, string fallback) =>
            values.GetValueOrDefault(cliKey) ?? ini?.Get("server", iniKey) ?? fallback;
        int GetInt(string key, int fallback, int min, int max)
        {
            string iniKey = key[2..].Replace('-', '_');
            string raw = Get(key, iniKey, fallback.ToString());
            if (!int.TryParse(raw, out int value) || value < min || value > max)
                throw new ArgumentException($"{key} 必须在 {min} 到 {max} 之间。");
            return value;
        }

        string targetHost = Get("--target-host", "target_host", "");
        string token = Get("--token", "token", Environment.GetEnvironmentVariable("TERRARIA_RELAY_TOKEN") ?? "");
        if (string.IsNullOrWhiteSpace(targetHost))
            throw new ArgumentException("必须提供 --target-host。");
        if (token.Length < 8)
            throw new ArgumentException("令牌至少需要 8 个字符，建议使用 16 个以上的随机字符。");

        string listenRaw = Get("--listen-address", "listen_address", "::");
        if (!IPAddress.TryParse(listenRaw, out IPAddress? listen) || listen.AddressFamily != System.Net.Sockets.AddressFamily.InterNetworkV6)
            throw new ArgumentException("--listen-address 必须是 IPv6 地址。");

        return new ServerOptions(
            listen,
            GetInt("--listen-port", 17777, 1, 65535),
            targetHost,
            GetInt("--target-port", 7777, 1, 65535),
            token,
            GetInt("--max-connections", 64, 1, 4096),
            GetInt("--connect-timeout", 10, 1, 120),
            GetInt("--handshake-timeout", 10, 1, 120),
            GetInt("--keepalive", 15, 5, 600));
    }
}
