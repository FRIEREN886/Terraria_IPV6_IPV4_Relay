using TerrariaRelay.Server;
using System.Net.Sockets;

if (args.Any(a => a is "--help" or "-h"))
{
    Console.WriteLine(ServerOptions.Help);
    return 0;
}

ServerOptions? parsedOptions = null;
try
{
    parsedOptions = ServerOptions.Parse(args);
    var shutdown = new CancellationTokenSource();
    void RequestShutdown()
    {
        try
        {
            if (!shutdown.IsCancellationRequested)
                shutdown.Cancel();
        }
        catch (ObjectDisposedException) { }
    }

    ConsoleCancelEventHandler cancelHandler = (_, eventArgs) =>
    {
        eventArgs.Cancel = true;
        Console.WriteLine("正在停止中继服务……");
        RequestShutdown();
    };
    EventHandler exitHandler = (_, _) => RequestShutdown();
    Console.CancelKeyPress += cancelHandler;
    AppDomain.CurrentDomain.ProcessExit += exitHandler;

    try
    {
        await new RelayServer(parsedOptions).RunAsync(shutdown.Token);
        return 0;
    }
    finally
    {
        Console.CancelKeyPress -= cancelHandler;
        AppDomain.CurrentDomain.ProcessExit -= exitHandler;
        shutdown.Dispose();
    }
}
catch (ArgumentException ex)
{
    Console.Error.WriteLine($"参数错误: {ex.Message}\n\n{ServerOptions.Help}");
    return 2;
}
catch (SocketException ex) when (ex.SocketErrorCode == SocketError.AddressAlreadyInUse)
{
    string endpoint = parsedOptions is null
        ? "配置的监听端口"
        : $"[{parsedOptions.ListenAddress}]:{parsedOptions.ListenPort}";
    Console.Error.WriteLine($"服务端启动失败: {endpoint} 已被其他进程占用。请停止旧的中继进程，或修改 INI 中的 listen_port。");
    return 3;
}
catch (Exception ex)
{
    Console.Error.WriteLine($"服务端启动失败: {ex.Message}");
    return 1;
}
