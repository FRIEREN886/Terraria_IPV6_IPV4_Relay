using System.Runtime.CompilerServices;

[assembly: InternalsVisibleTo("TerrariaRelay.Tests")]
