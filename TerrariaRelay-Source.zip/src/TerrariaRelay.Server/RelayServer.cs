using System.Net;
using System.Net.Sockets;
using System.Collections.Concurrent;
using TerrariaRelay.Protocol;

namespace TerrariaRelay.Server;

internal sealed class RelayServer(ServerOptions options)
{
    private readonly SemaphoreSlim _slots = new(options.MaxConnections, options.MaxConnections);
    private readonly ConcurrentDictionary<long, Task> _sessions = new();
    private long _connectionId;
    private int _active;

    public async Task RunAsync(CancellationToken cancellationToken)
    {
        var listener = new TcpListener(options.ListenAddress, options.ListenPort);
        listener.Server.DualMode = false;
        listener.Start(512);
        Log("INFO", $"监听 [{options.ListenAddress}]:{options.ListenPort}");
        Log("INFO", $"固定目标 {options.TargetHost}:{options.TargetPort}，最大连接 {options.MaxConnections}");

        try
        {
            while (!cancellationToken.IsCancellationRequested)
            {
                Socket client = await listener.AcceptSocketAsync(cancellationToken);
                long id = Interlocked.Increment(ref _connectionId);
                if (!_slots.Wait(0))
                {
                    Log("WARN", $"#{id} 已拒绝：达到连接上限，来源 {client.RemoteEndPoint}");
                    client.Dispose();
                    continue;
                }

                Task session = HandleAsync(id, client, cancellationToken);
                _sessions[id] = session;
                _ = ObserveSessionAsync(id, session);
            }
        }
        catch (OperationCanceledException) when (cancellationToken.IsCancellationRequested) { }
        finally
        {
            listener.Stop();
            await Task.WhenAll(_sessions.Values);
            Log("INFO", "监听已停止。");
        }
    }

    private async Task HandleAsync(long id, Socket client, CancellationToken serverCancellation)
    {
        int active = Interlocked.Increment(ref _active);
        Log("INFO", $"#{id} 已连接，来源 {client.RemoteEndPoint}，当前 {active}");
        Socket? target = null;
        try
        {
            SocketUtilities.Configure(client, options.KeepAliveSeconds);
            using var clientStream = new NetworkStream(client, ownsSocket: false);
            using var handshakeCts = CancellationTokenSource.CreateLinkedTokenSource(serverCancellation);
            handshakeCts.CancelAfter(TimeSpan.FromSeconds(options.HandshakeTimeoutSeconds));

            if (!await RelayProtocol.AuthenticateAsServerAsync(clientStream, options.Token, handshakeCts.Token))
            {
                await RelayProtocol.WriteResponseAsync(clientStream, false, "鉴权失败。", handshakeCts.Token);
                Log("WARN", $"#{id} 鉴权失败，来源 {client.RemoteEndPoint}");
                return;
            }

            try
            {
                target = await SocketUtilities.ConnectAsync(
                    options.TargetHost,
                    options.TargetPort,
                    TimeSpan.FromSeconds(options.ConnectTimeoutSeconds),
                    options.KeepAliveSeconds,
                    requireIpv6: false,
                    serverCancellation);
            }
            catch (Exception ex) when (ex is SocketException or OperationCanceledException)
            {
                await RelayProtocol.WriteResponseAsync(clientStream, false, "中继无法连接 Terraria 服务端。", handshakeCts.Token);
                Log("WARN", $"#{id} 目标连接失败: {ex.Message}");
                return;
            }

            await RelayProtocol.WriteResponseAsync(clientStream, true, "OK", handshakeCts.Token);
            Log("INFO", $"#{id} 中继已建立 -> {target.RemoteEndPoint}");
            long up = 0;
            long down = 0;
            await StreamRelay.RunAsync(client, target, (upDelta, downDelta) =>
            {
                Interlocked.Add(ref up, upDelta);
                Interlocked.Add(ref down, downDelta);
            }, serverCancellation);
            Log("INFO", $"#{id} 已断开，上传 {FormatBytes(up)}，下载 {FormatBytes(down)}");
        }
        catch (OperationCanceledException) when (serverCancellation.IsCancellationRequested) { }
        catch (OperationCanceledException) { Log("WARN", $"#{id} 握手超时。"); }
        catch (Exception ex) when (ex is IOException or SocketException or RelayProtocolException)
        {
            Log("WARN", $"#{id} 连接结束: {ex.Message}");
        }
        finally
        {
            target?.Dispose();
            client.Dispose();
            _slots.Release();
            Interlocked.Decrement(ref _active);
        }
    }

    private async Task ObserveSessionAsync(long id, Task session)
    {
        try { await session; }
        catch (Exception ex) { Log("ERROR", $"#{id} 未处理异常: {ex.Message}"); }
        finally { _sessions.TryRemove(id, out _); }
    }

    private static string FormatBytes(long bytes) => bytes switch
    {
        >= 1024 * 1024 => $"{bytes / 1024d / 1024d:F1} MiB",
        >= 1024 => $"{bytes / 1024d:F1} KiB",
        _ => $"{bytes} B"
    };

    private static void Log(string level, string message) =>
        Console.WriteLine($"{DateTimeOffset.Now:yyyy-MM-dd HH:mm:ss zzz} [{level}] {message}");
}
