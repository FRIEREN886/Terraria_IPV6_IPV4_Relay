namespace TerrariaRelay.Server;

internal sealed class IniConfiguration
{
    private readonly Dictionary<string, string> _values = new(StringComparer.OrdinalIgnoreCase);

    public static IniConfiguration Load(string path)
    {
        if (!File.Exists(path))
            throw new ArgumentException($"找不到 INI 配置文件: {path}");

        var configuration = new IniConfiguration();
        string section = "server";
        int lineNumber = 0;
        foreach (string sourceLine in File.ReadLines(path))
        {
            lineNumber++;
            string line = sourceLine.Trim();
            if (line.Length == 0 || line.StartsWith(';') || line.StartsWith('#'))
                continue;

            if (line.StartsWith('[') && line.EndsWith(']'))
            {
                section = line[1..^1].Trim();
                if (section.Length == 0)
                    throw new ArgumentException($"INI 第 {lineNumber} 行的节名称为空。");
                continue;
            }

            int separator = line.IndexOf('=');
            if (separator <= 0)
                throw new ArgumentException($"INI 第 {lineNumber} 行格式错误，应为 key=value。");

            string key = line[..separator].Trim().Replace('-', '_');
            string value = line[(separator + 1)..].Trim();
            if (value.Length >= 2 && ((value[0] == '"' && value[^1] == '"') ||
                                     (value[0] == '\'' && value[^1] == '\'')))
                value = value[1..^1];
            configuration._values[$"{section}.{key}"] = value;
        }
        return configuration;
    }

    public string? Get(string section, string key) =>
        _values.GetValueOrDefault($"{section}.{key.Replace('-', '_')}");

    public void ValidateServerKeys(IReadOnlySet<string> allowedKeys)
    {
        foreach (string fullKey in _values.Keys)
        {
            int dot = fullKey.IndexOf('.');
            string section = dot >= 0 ? fullKey[..dot] : "";
            string key = dot >= 0 ? fullKey[(dot + 1)..] : fullKey;
            if (!section.Equals("server", StringComparison.OrdinalIgnoreCase))
                throw new ArgumentException($"INI 中存在不支持的节 [{section}]。");
            if (!allowedKeys.Contains(key))
                throw new ArgumentException($"INI 中存在未知配置项: {key}");
        }
    }
}
