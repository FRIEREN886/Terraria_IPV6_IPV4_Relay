using System.ComponentModel;
using System.IO;
using System.Net;
using System.Windows;
using System.Windows.Media;
using System.Windows.Threading;
using TerrariaRelay.Protocol;

namespace TerrariaRelay.Client;

public partial class MainWindow : Window
{
    private readonly ClientRelayService _relay = new();
    private readonly DispatcherTimer _trafficTimer;
    private ClientConfig _config = ConfigStore.Load();
    private int _activeConnections;
    private long _totalUpstream;
    private long _totalDownstream;
    private long _lastUpstream;
    private long _lastDownstream;
    private DateTimeOffset _lastSampleTime = DateTimeOffset.Now;
    private DateTimeOffset? _runningSince;
    private TimeSpan _lastRunDuration;

    public MainWindow()
    {
        InitializeComponent();
        LoadFields();
        _relay.Log += message => Dispatcher.Invoke(() => AppendLog(message));
        _relay.MetricsChanged += (active, up, down) => Dispatcher.Invoke(() => UpdateTotals(active, up, down));
        _trafficTimer = new DispatcherTimer(DispatcherPriority.Background)
        {
            Interval = TimeSpan.FromSeconds(1)
        };
        _trafficTimer.Tick += TrafficTimer_Tick;
        _trafficTimer.Start();
        AppendLog("准备就绪。启动后，在 Terraria 中连接 127.0.0.1:7777。");
    }

    private async void Start_Click(object sender, RoutedEventArgs e)
    {
        StartButton.IsEnabled = false;
        try
        {
            _config = ReadAndValidateFields();
            ConfigStore.Save(_config);
            SetChecking();
            await _relay.TestHandshakeAsync(_config);
            _relay.ResetMetrics();
            ResetTrafficSession();
            await _relay.StartAsync(_config);
            _runningSince = DateTimeOffset.Now;
            SetRunning(true);
            AppendLog($"IPv6 目标：[{TerrariaRelay.Protocol.SocketUtilities.NormalizeHost(_config.RelayHost)}]:{_config.RelayPort}");
        }
        catch (Exception ex) when (ex is ArgumentException or IOException or UnauthorizedAccessException or
                                             System.Net.Sockets.SocketException or RelayProtocolException or
                                             OperationCanceledException)
        {
            SetRunning(false);
            MessageBox.Show(this, ex.Message, "无法启动", MessageBoxButton.OK, MessageBoxImage.Warning);
        }
    }

    private async void Stop_Click(object sender, RoutedEventArgs e)
    {
        StopButton.IsEnabled = false;
        await _relay.StopAsync();
        if (_runningSince is not null)
            _lastRunDuration = DateTimeOffset.Now - _runningSince.Value;
        _runningSince = null;
        SetRunning(false);
    }

    private async void Window_Closing(object? sender, CancelEventArgs e)
    {
        try
        {
            _config = ReadFieldsWithoutValidation();
            ConfigStore.Save(_config);
        }
        catch (Exception) { }
        _trafficTimer.Stop();
        await _relay.StopAsync();
    }

    private void CopyLogs_Click(object sender, RoutedEventArgs e)
    {
        if (!string.IsNullOrEmpty(LogBox.Text)) Clipboard.SetText(LogBox.Text);
    }

    private void LoadFields()
    {
        RelayHostBox.Text = _config.RelayHost;
        RelayPortBox.Text = _config.RelayPort.ToString();
        TokenBox.Password = _config.GetToken();
        LocalAddressBox.Text = _config.LocalAddress;
        LocalPortBox.Text = _config.LocalPort.ToString();
        TimeoutBox.Text = _config.ConnectTimeoutSeconds.ToString();
        KeepAliveBox.Text = _config.KeepAliveSeconds.ToString();
    }

    private ClientConfig ReadAndValidateFields()
    {
        ClientConfig config = ReadFieldsWithoutValidation();
        if (string.IsNullOrWhiteSpace(config.RelayHost)) throw new ArgumentException("请填写 Ubuntu 的公网 IPv6 或域名。");
        if (config.GetToken().Length < 8) throw new ArgumentException("访问令牌至少需要 8 个字符。");
        if (!IPAddress.TryParse(config.LocalAddress, out _)) throw new ArgumentException("本地监听地址无效。");
        return config;
    }

    private ClientConfig ReadFieldsWithoutValidation()
    {
        var config = new ClientConfig
        {
            RelayHost = RelayHostBox.Text.Trim(),
            RelayPort = ParseRange(RelayPortBox.Text, "中继端口", 1, 65535),
            LocalAddress = LocalAddressBox.Text.Trim(),
            LocalPort = ParseRange(LocalPortBox.Text, "本地端口", 1, 65535),
            ConnectTimeoutSeconds = ParseRange(TimeoutBox.Text, "连接超时", 1, 120),
            KeepAliveSeconds = ParseRange(KeepAliveBox.Text, "Keepalive", 5, 600)
        };
        config.SetToken(TokenBox.Password);
        return config;
    }

    private void SetRunning(bool running)
    {
        StartButton.IsEnabled = !running;
        StopButton.IsEnabled = running;
        RelayHostBox.IsEnabled = !running; RelayPortBox.IsEnabled = !running; TokenBox.IsEnabled = !running;
        LocalAddressBox.IsEnabled = !running; LocalPortBox.IsEnabled = !running;
        TimeoutBox.IsEnabled = !running; KeepAliveBox.IsEnabled = !running;
        StatusText.Text = running ? "握手成功" : "未启动";
        StatusText.Foreground = new SolidColorBrush((Color)ColorConverter.ConvertFromString(running ? "#166534" : "#475467"));
        StatusDot.Fill = new SolidColorBrush((Color)ColorConverter.ConvertFromString(running ? "#22C55E" : "#98A2B3"));
        StatusPill.Background = new SolidColorBrush((Color)ColorConverter.ConvertFromString(running ? "#DCFCE7" : "#E4E7EC"));
    }

    private void SetChecking()
    {
        StatusText.Text = "正在握手";
        StatusText.Foreground = new SolidColorBrush((Color)ColorConverter.ConvertFromString("#92400E"));
        StatusDot.Fill = new SolidColorBrush((Color)ColorConverter.ConvertFromString("#F59E0B"));
        StatusPill.Background = new SolidColorBrush((Color)ColorConverter.ConvertFromString("#FEF3C7"));
    }

    private void AppendLog(string message)
    {
        LogBox.AppendText($"[{DateTime.Now:HH:mm:ss}] {message}{Environment.NewLine}");
        if (LogBox.LineCount > 1000)
        {
            int trimAt = LogBox.GetCharacterIndexFromLineIndex(200);
            LogBox.Text = LogBox.Text[trimAt..];
        }
        LogBox.ScrollToEnd();
    }

    private void UpdateTotals(int active, long upstream, long downstream)
    {
        _activeConnections = active;
        _totalUpstream = upstream;
        _totalDownstream = downstream;
        MetricsText.Text = $"连接 {active}  ·  ↑ {FormatBytes(upstream)}  ↓ {FormatBytes(downstream)}";
        ActiveConnectionsText.Text = active.ToString();
        TotalUploadText.Text = FormatBytes(upstream);
        TotalDownloadText.Text = FormatBytes(downstream);
    }

    private void TrafficTimer_Tick(object? sender, EventArgs e)
    {
        DateTimeOffset now = DateTimeOffset.Now;
        double elapsed = Math.Max(0.05, (now - _lastSampleTime).TotalSeconds);
        long upstreamDelta = Math.Max(0, _totalUpstream - _lastUpstream);
        long downstreamDelta = Math.Max(0, _totalDownstream - _lastDownstream);
        double uploadRate = upstreamDelta / elapsed;
        double downloadRate = downstreamDelta / elapsed;

        TrafficGraph.AppendSample(now, uploadRate, downloadRate);
        UploadSpeedText.Text = FormatRate(uploadRate);
        DownloadSpeedText.Text = FormatRate(downloadRate);
        ActiveConnectionsText.Text = _activeConnections.ToString();
        TotalUploadText.Text = FormatBytes(_totalUpstream);
        TotalDownloadText.Text = FormatBytes(_totalDownstream);
        TimeSpan duration = _runningSince is null ? _lastRunDuration : now - _runningSince.Value;
        RunTimeText.Text = FormatDuration(duration);

        _lastUpstream = _totalUpstream;
        _lastDownstream = _totalDownstream;
        _lastSampleTime = now;
    }

    private void ResetTrafficSession()
    {
        _activeConnections = 0;
        _totalUpstream = 0;
        _totalDownstream = 0;
        _lastUpstream = 0;
        _lastDownstream = 0;
        _lastSampleTime = DateTimeOffset.Now;
        _lastRunDuration = TimeSpan.Zero;
        TrafficGraph.Clear();
        UpdateTotals(0, 0, 0);
        UploadSpeedText.Text = "0 B/s";
        DownloadSpeedText.Text = "0 B/s";
        RunTimeText.Text = "00:00:00";
    }

    private static int ParseRange(string raw, string name, int min, int max)
    {
        if (!int.TryParse(raw, out int value) || value < min || value > max)
            throw new ArgumentException($"{name} 必须在 {min} 到 {max} 之间。");
        return value;
    }

    private static string FormatBytes(long bytes) => bytes switch
    {
        >= 1024 * 1024 * 1024 => $"{bytes / 1024d / 1024d / 1024d:F1} GiB",
        >= 1024 * 1024 => $"{bytes / 1024d / 1024d:F1} MiB",
        >= 1024 => $"{bytes / 1024d:F1} KiB",
        _ => $"{bytes} B"
    };

    private static string FormatRate(double bytesPerSecond) => $"{FormatBytes((long)Math.Round(bytesPerSecond))}/s";

    private static string FormatDuration(TimeSpan duration) =>
        duration.TotalHours >= 100
            ? $"{(int)duration.TotalDays}天 {duration:hh\\:mm\\:ss}"
            : $"{(int)duration.TotalHours:00}:{duration.Minutes:00}:{duration.Seconds:00}";
}
