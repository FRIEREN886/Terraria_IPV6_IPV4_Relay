using System.Security.Cryptography;
using System.Text;
using System.Text.Json;
using System.IO;

namespace TerrariaRelay.Client;

internal sealed class ClientConfig
{
    public string RelayHost { get; set; } = "2001:db8::1";
    public int RelayPort { get; set; } = 17777;
    public string LocalAddress { get; set; } = "127.0.0.1";
    public int LocalPort { get; set; } = 7777;
    public int ConnectTimeoutSeconds { get; set; } = 10;
    public int KeepAliveSeconds { get; set; } = 15;
    public string ProtectedToken { get; set; } = "";

    public string GetToken()
    {
        if (string.IsNullOrEmpty(ProtectedToken)) return "";
        try
        {
            byte[] encrypted = Convert.FromBase64String(ProtectedToken);
            byte[] plain = ProtectedData.Unprotect(encrypted, null, DataProtectionScope.CurrentUser);
            return Encoding.UTF8.GetString(plain);
        }
        catch (CryptographicException) { return ""; }
        catch (FormatException) { return ""; }
    }

    public void SetToken(string token)
    {
        byte[] plain = Encoding.UTF8.GetBytes(token);
        ProtectedToken = Convert.ToBase64String(ProtectedData.Protect(plain, null, DataProtectionScope.CurrentUser));
    }
}

internal static class ConfigStore
{
    private static readonly string DirectoryPath = Path.Combine(
        Environment.GetFolderPath(Environment.SpecialFolder.LocalApplicationData), "TerrariaIPv6Relay");
    private static readonly string FilePath = Path.Combine(DirectoryPath, "config.json");

    public static ClientConfig Load()
    {
        try
        {
            if (!File.Exists(FilePath)) return new ClientConfig();
            return JsonSerializer.Deserialize<ClientConfig>(File.ReadAllText(FilePath)) ?? new ClientConfig();
        }
        catch (Exception ex) when (ex is IOException or JsonException or UnauthorizedAccessException)
        {
            return new ClientConfig();
        }
    }

    public static void Save(ClientConfig config)
    {
        Directory.CreateDirectory(DirectoryPath);
        string temporary = FilePath + ".tmp";
        File.WriteAllText(temporary, JsonSerializer.Serialize(config, new JsonSerializerOptions { WriteIndented = true }));
        File.Move(temporary, FilePath, true);
    }
}
