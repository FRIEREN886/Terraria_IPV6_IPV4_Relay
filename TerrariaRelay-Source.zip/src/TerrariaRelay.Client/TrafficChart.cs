using System.Globalization;
using System.Windows;
using System.Windows.Media;

namespace TerrariaRelay.Client;

public sealed class TrafficChart : FrameworkElement
{
    private const int WindowSeconds = 10 * 60;
    private readonly List<TrafficSample> _samples = [];
    private static readonly Brush GridBrush = MakeBrush("#E4E7EC");
    private static readonly Brush AxisBrush = MakeBrush("#667085");
    private static readonly Brush HeaderBrush = MakeBrush("#344054");
    private static readonly Brush UploadBrush = MakeBrush("#F59E0B");
    private static readonly Brush DownloadBrush = MakeBrush("#1687F8");
    private static readonly Pen UploadPen = MakePen(UploadBrush, 2.2);
    private static readonly Pen DownloadPen = MakePen(DownloadBrush, 2.4);

    public TrafficChart()
    {
        SnapsToDevicePixels = true;
        UseLayoutRounding = true;
    }

    public void AppendSample(DateTimeOffset time, double uploadBytesPerSecond, double downloadBytesPerSecond)
    {
        _samples.Add(new TrafficSample(time, Math.Max(0, uploadBytesPerSecond), Math.Max(0, downloadBytesPerSecond)));
        DateTimeOffset cutoff = time.AddSeconds(-WindowSeconds);
        _samples.RemoveAll(sample => sample.Time < cutoff);
        InvalidateVisual();
    }

    public void Clear()
    {
        _samples.Clear();
        InvalidateVisual();
    }

    protected override void OnRender(DrawingContext drawingContext)
    {
        base.OnRender(drawingContext);
        if (ActualWidth < 180 || ActualHeight < 120) return;

        const double left = 58;
        const double top = 38;
        const double right = 18;
        const double bottom = 30;
        var plot = new Rect(left, top, Math.Max(1, ActualWidth - left - right), Math.Max(1, ActualHeight - top - bottom));
        DateTimeOffset now = _samples.Count > 0 ? _samples[^1].Time : DateTimeOffset.Now;
        double observedMax = _samples.Count == 0 ? 0 : _samples.Max(s => Math.Max(s.Upload, s.Download));
        double axisMax = NiceMaximum(Math.Max(1024, observedMax * 1.15));

        DrawHeader(drawingContext);
        DrawGridAndAxes(drawingContext, plot, now, axisMax);
        if (_samples.Count == 0)
        {
            DrawCenteredText(drawingContext, "等待流量数据…", plot, AxisBrush, 12);
            return;
        }

        List<Point> uploadPoints = BuildPoints(plot, now, axisMax, static sample => sample.Upload);
        List<Point> downloadPoints = BuildPoints(plot, now, axisMax, static sample => sample.Download);
        DrawArea(drawingContext, downloadPoints, plot, Color.FromArgb(30, 22, 135, 248));
        DrawSmoothLine(drawingContext, downloadPoints, DownloadPen);
        DrawSmoothLine(drawingContext, uploadPoints, UploadPen);
    }

    private void DrawHeader(DrawingContext dc)
    {
        DrawText(dc, "最近 10 分钟", new Point(14, 10), HeaderBrush, 12, FontWeights.SemiBold);
        double right = ActualWidth - 16;
        double downloadWidth = Measure("下载", 12, FontWeights.SemiBold);
        DrawText(dc, "下载", new Point(right - downloadWidth, 10), DownloadBrush, 12, FontWeights.SemiBold);
        right -= downloadWidth + 24;
        double uploadWidth = Measure("上传", 12, FontWeights.SemiBold);
        DrawText(dc, "上传", new Point(right - uploadWidth, 10), UploadBrush, 12, FontWeights.SemiBold);
    }

    private static void DrawGridAndAxes(DrawingContext dc, Rect plot, DateTimeOffset now, double axisMax)
    {
        var gridPen = MakePen(GridBrush, 1);
        for (int i = 0; i <= 4; i++)
        {
            double y = plot.Top + plot.Height * i / 4d;
            dc.DrawLine(gridPen, new Point(plot.Left, y), new Point(plot.Right, y));
            DrawText(dc, FormatRate(axisMax * (1 - i / 4d)), new Point(4, y - 8), AxisBrush, 10);
        }

        for (int i = 0; i <= 5; i++)
        {
            double x = plot.Left + plot.Width * i / 5d;
            dc.DrawLine(gridPen, new Point(x, plot.Top), new Point(x, plot.Bottom));
            DateTimeOffset labelTime = now.AddSeconds(-WindowSeconds + WindowSeconds * i / 5d);
            string label = labelTime.ToLocalTime().ToString("HH:mm", CultureInfo.InvariantCulture);
            double width = Measure(label, 10, FontWeights.Normal);
            DrawText(dc, label, new Point(Math.Clamp(x - width / 2, plot.Left, plot.Right - width), plot.Bottom + 8), AxisBrush, 10);
        }
    }

    private List<Point> BuildPoints(Rect plot, DateTimeOffset now, double axisMax, Func<TrafficSample, double> selector)
    {
        DateTimeOffset start = now.AddSeconds(-WindowSeconds);
        var points = new List<Point>(_samples.Count + 1) { new(plot.Left, plot.Bottom) };
        foreach (TrafficSample sample in _samples)
        {
            double progress = (sample.Time - start).TotalSeconds / WindowSeconds;
            double x = plot.Left + Math.Clamp(progress, 0, 1) * plot.Width;
            double y = plot.Bottom - Math.Clamp(selector(sample) / axisMax, 0, 1) * plot.Height;
            points.Add(new Point(x, y));
        }
        return points;
    }

    private static void DrawSmoothLine(DrawingContext dc, IReadOnlyList<Point> points, Pen pen)
    {
        if (points.Count < 2) return;
        var geometry = new StreamGeometry();
        using (StreamGeometryContext context = geometry.Open())
        {
            context.BeginFigure(points[0], false, false);
            for (int i = 1; i < points.Count; i++)
            {
                Point previous = points[i - 1];
                Point current = points[i];
                double controlX = (previous.X + current.X) / 2;
                context.BezierTo(new Point(controlX, previous.Y), new Point(controlX, current.Y), current, true, false);
            }
        }
        geometry.Freeze();
        dc.DrawGeometry(null, pen, geometry);
    }

    private static void DrawArea(DrawingContext dc, IReadOnlyList<Point> points, Rect plot, Color color)
    {
        if (points.Count < 2) return;
        var geometry = new StreamGeometry();
        using (StreamGeometryContext context = geometry.Open())
        {
            context.BeginFigure(new Point(points[0].X, plot.Bottom), true, true);
            context.LineTo(points[0], false, false);
            for (int i = 1; i < points.Count; i++) context.LineTo(points[i], true, false);
            context.LineTo(new Point(points[^1].X, plot.Bottom), false, false);
        }
        geometry.Freeze();
        var brush = new LinearGradientBrush(
            Color.FromArgb((byte)Math.Min(255, color.A * 2), color.R, color.G, color.B),
            Color.FromArgb(0, color.R, color.G, color.B), new Point(0, 0), new Point(0, 1));
        brush.Freeze();
        dc.DrawGeometry(brush, null, geometry);
    }

    private static double NiceMaximum(double value)
    {
        double exponent = Math.Pow(10, Math.Floor(Math.Log10(value)));
        double fraction = value / exponent;
        double nice = fraction <= 1 ? 1 : fraction <= 2 ? 2 : fraction <= 5 ? 5 : 10;
        return nice * exponent;
    }

    private static string FormatRate(double bytesPerSecond) => bytesPerSecond switch
    {
        >= 1024 * 1024 => $"{bytesPerSecond / 1024d / 1024d:0.#}M",
        >= 1024 => $"{bytesPerSecond / 1024d:0.#}K",
        _ => $"{bytesPerSecond:0}B"
    };

    private static void DrawCenteredText(DrawingContext dc, string text, Rect rect, Brush brush, double size)
    {
        double width = Measure(text, size, FontWeights.Normal);
        DrawText(dc, text, new Point(rect.Left + (rect.Width - width) / 2, rect.Top + rect.Height / 2 - 8), brush, size);
    }

    private static void DrawText(DrawingContext dc, string text, Point point, Brush brush, double size, FontWeight? weight = null)
    {
        var formatted = new FormattedText(text, CultureInfo.CurrentUICulture, FlowDirection.LeftToRight,
            new Typeface(new FontFamily("Segoe UI, Microsoft YaHei UI"), FontStyles.Normal, weight ?? FontWeights.Normal, FontStretches.Normal),
            size, brush, PixelsPerDip);
        dc.DrawText(formatted, point);
    }

    private static double Measure(string text, double size, FontWeight weight)
    {
        var formatted = new FormattedText(text, CultureInfo.CurrentUICulture, FlowDirection.LeftToRight,
            new Typeface(new FontFamily("Segoe UI, Microsoft YaHei UI"), FontStyles.Normal, weight, FontStretches.Normal),
            size, Brushes.Black, PixelsPerDip);
        return formatted.WidthIncludingTrailingWhitespace;
    }

    private static double PixelsPerDip => Application.Current?.MainWindow is Visual visual
        ? VisualTreeHelper.GetDpi(visual).PixelsPerDip
        : 1.0;

    private static SolidColorBrush MakeBrush(string color)
    {
        var brush = new SolidColorBrush((Color)ColorConverter.ConvertFromString(color));
        brush.Freeze();
        return brush;
    }

    private static Pen MakePen(Brush brush, double thickness)
    {
        var pen = new Pen(brush, thickness) { StartLineCap = PenLineCap.Round, EndLineCap = PenLineCap.Round, LineJoin = PenLineJoin.Round };
        pen.Freeze();
        return pen;
    }

    private sealed record TrafficSample(DateTimeOffset Time, double Upload, double Download);
}
