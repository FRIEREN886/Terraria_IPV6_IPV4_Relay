using System.Net;
using System.Net.Sockets;
using System.IO;
using TerrariaRelay.Protocol;

namespace TerrariaRelay.Client;

internal sealed class ClientRelayService
{
    private CancellationTokenSource? _shutdown;
    private TcpListener? _listener;
    private int _active;
    private long _upstream;
    private long _downstream;
    private long _connectionId;

    public event Action<string>? Log;
    public event Action<int, long, long>? MetricsChanged;

    public bool IsRunning => _shutdown is { IsCancellationRequested: false };

    public void ResetMetrics()
    {
        Interlocked.Exchange(ref _upstream, 0);
        Interlocked.Exchange(ref _downstream, 0);
        RaiseMetrics();
    }

    public async Task TestHandshakeAsync(ClientConfig config, CancellationToken cancellationToken = default)
    {
        using Socket relay = await SocketUtilities.ConnectAsync(
            config.RelayHost,
            config.RelayPort,
            TimeSpan.FromSeconds(config.ConnectTimeoutSeconds),
            config.KeepAliveSeconds,
            requireIpv6: true,
            cancellationToken);
        using var relayStream = new NetworkStream(relay, ownsSocket: false);
        using var handshakeCts = CancellationTokenSource.CreateLinkedTokenSource(cancellationToken);
        handshakeCts.CancelAfter(TimeSpan.FromSeconds(config.ConnectTimeoutSeconds));
        await RelayProtocol.AuthenticateAsClientAsync(relayStream, config.GetToken(), handshakeCts.Token);
        (bool success, string message) = await RelayProtocol.ReadResponseAsync(relayStream, handshakeCts.Token);
        if (!success)
            throw new RelayProtocolException(message);
        Log?.Invoke("✓ 与 Ubuntu 握手成功，Terraria 服务端可达。");
    }

    public Task StartAsync(ClientConfig config)
    {
        if (IsRunning) throw new InvalidOperationException("中继已经在运行。");
        if (!IPAddress.TryParse(config.LocalAddress, out IPAddress? localAddress))
            throw new ArgumentException("本地监听地址不是有效的 IP 地址。");

        _listener = new TcpListener(localAddress, config.LocalPort);
        _listener.Start(128);
        _shutdown = new CancellationTokenSource();
        Log?.Invoke($"正在监听 {config.LocalAddress}:{config.LocalPort}");
        _ = AcceptLoopAsync(config, _shutdown.Token);
        return Task.CompletedTask;
    }

    public async Task StopAsync()
    {
        CancellationTokenSource? shutdown = _shutdown;
        if (shutdown is null) return;
        shutdown.Cancel();
        _listener?.Stop();
        await Task.Delay(50);
        shutdown.Dispose();
        _shutdown = null;
        _listener = null;
        Log?.Invoke("本地中继已停止。");
    }

    private async Task AcceptLoopAsync(ClientConfig config, CancellationToken cancellationToken)
    {
        try
        {
            while (!cancellationToken.IsCancellationRequested)
            {
                Socket local = await _listener!.AcceptSocketAsync(cancellationToken);
                long id = Interlocked.Increment(ref _connectionId);
                _ = HandleConnectionAsync(id, local, config, cancellationToken);
            }
        }
        catch (OperationCanceledException) when (cancellationToken.IsCancellationRequested) { }
        catch (SocketException) when (cancellationToken.IsCancellationRequested) { }
        catch (Exception ex) { Log?.Invoke($"监听异常：{ex.Message}"); }
    }

    private async Task HandleConnectionAsync(long id, Socket local, ClientConfig config, CancellationToken cancellationToken)
    {
        Socket? relay = null;
        int active = Interlocked.Increment(ref _active);
        RaiseMetrics();
        Log?.Invoke($"#{id} Terraria 已接入，正在连接 IPv6 中继……");
        try
        {
            SocketUtilities.Configure(local, config.KeepAliveSeconds);
            relay = await SocketUtilities.ConnectAsync(
                config.RelayHost,
                config.RelayPort,
                TimeSpan.FromSeconds(config.ConnectTimeoutSeconds),
                config.KeepAliveSeconds,
                requireIpv6: true,
                cancellationToken);

            using var relayStream = new NetworkStream(relay, ownsSocket: false);
            using var handshakeCts = CancellationTokenSource.CreateLinkedTokenSource(cancellationToken);
            handshakeCts.CancelAfter(TimeSpan.FromSeconds(config.ConnectTimeoutSeconds));
            await RelayProtocol.AuthenticateAsClientAsync(relayStream, config.GetToken(), handshakeCts.Token);
            (bool success, string message) = await RelayProtocol.ReadResponseAsync(relayStream, handshakeCts.Token);
            if (!success) throw new RelayProtocolException(message);

            Log?.Invoke($"#{id} 握手成功，中继已建立 [{relay.RemoteEndPoint}]");
            await StreamRelay.RunAsync(local, relay, (up, down) =>
            {
                Interlocked.Add(ref _upstream, up);
                Interlocked.Add(ref _downstream, down);
                RaiseMetrics();
            }, cancellationToken);
            Log?.Invoke($"#{id} 连接已结束。");
        }
        catch (OperationCanceledException) when (cancellationToken.IsCancellationRequested) { }
        catch (SocketException ex) { Log?.Invoke($"#{id} 网络错误：{FriendlySocketError(ex)}"); }
        catch (OperationCanceledException) { Log?.Invoke($"#{id} 连接或握手超时。"); }
        catch (Exception ex) when (ex is IOException or RelayProtocolException)
        {
            Log?.Invoke($"#{id} 中继拒绝：{ex.Message}");
        }
        finally
        {
            relay?.Dispose();
            local.Dispose();
            Interlocked.Decrement(ref _active);
            RaiseMetrics();
        }
    }

    private static string FriendlySocketError(SocketException ex) => ex.SocketErrorCode switch
    {
        SocketError.HostNotFound => "找不到中继主机。",
        SocketError.AddressFamilyNotSupported => "该主机没有可用的 IPv6 地址。",
        SocketError.ConnectionRefused => "连接被拒绝，请检查服务端和端口。",
        SocketError.NetworkUnreachable => "IPv6 网络不可达。",
        SocketError.TimedOut => "连接超时。",
        _ => ex.Message
    };

    private void RaiseMetrics() => MetricsChanged?.Invoke(
        Volatile.Read(ref _active), Volatile.Read(ref _upstream), Volatile.Read(ref _downstream));
}
